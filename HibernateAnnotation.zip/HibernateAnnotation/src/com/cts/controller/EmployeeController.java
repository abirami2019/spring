package com.cts.controller;

import com.cts.entity.Employee;
import com.cts.service.EmployeeService;
import com.cts.service.EmployeeServiceImpl;

public class EmployeeController {
	public static void main(String arg[]) {
		EmployeeService servImpl = new EmployeeServiceImpl();
		servImpl.addEmployee(new Employee());
		servImpl.showEmployee();
	}

}
