package com.cts.service;

import com.cts.dao.EmployeeDao;
import com.cts.dao.EmployeeDaoImpl;
import com.cts.entity.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDao employeeDao =new EmployeeDaoImpl();

	@Override
	public void addEmployee(Employee emp) {
		employeeDao.addEmployee(emp);
		
	}

	@Override
	public void showEmployee() {
		employeeDao.showEmployee();
		
	}
	

}
