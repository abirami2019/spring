package com.cts.service;

import com.cts.entity.Employee;

public interface EmployeeService {
public void addEmployee(Employee emp);
public void showEmployee();
}
