package com.cts.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.entity.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	SessionFactory sessionfactory;
	Session session;
	Transaction transaction;

	public void addEmployee(Employee emp) {
		sessionfactory = new Configuration().configure(
				"/resources/hibernate.cfg.xml").buildSessionFactory();
		session = sessionfactory.openSession();
		transaction = session.beginTransaction();
		emp.setEmployeeName("Abi");
		emp.setEmailId("abi@gmail.com");
		emp.setContactNo("38952799");
		session.save(emp);
		transaction.commit();
		System.out.println("Data has been inserted successfully");
		//session.close();
	}

	@Override
	public void showEmployee() {
		//sessionfactory = new Configuration().configure(
		//		"/resources/hibernate.cfg.xml").buildSessionFactory();
		//session = sessionfactory.openSession();
		transaction = session.beginTransaction();
		
		String selectQuery="from Employee";
		Query query=session.createQuery(selectQuery);
		List<Employee> list=query.list();
		for(Employee e:list)
		{
			System.out.println(e.getEmployeeId()+"\t"+e.getEmployeeName()+"\t"+e.getEmailId());
		}
		
		transaction.commit();
		session.close();
	}
}
