package com.cts.dao;

import com.cts.entity.Employee;

public interface EmployeeDao {
	public void addEmployee(Employee emp);
	public void showEmployee();
}
